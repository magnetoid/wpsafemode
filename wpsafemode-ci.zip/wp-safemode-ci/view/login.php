<?php


?>
<div class="row" data-equalizer>    
	<div class="large-4 columns text-left widget" data-equalizer-watch>
       	<div class="widget-title dashboard-panel ">
       		
			<h6 class="heading bold">Login to WP Safe Mode</h6>
			<p>username/password: demo/demo</p>
			<form action="" method="post">
				<ul>
		
			
				<li><label>Username/Email</label><input type="text" name="username" id="username" placeholder="Username" value=""/></li>		
				<li><label>Password</label><input type="password" name="password" id="password" placeholder="Password" value=""/></li>
		
	
				</ul>
				<input type='submit' class='btn btn-blue' name="submit_login" value="Login"> 
			</form>		
		</div>
	</div>
</div>