   
   
	<script src="assets/js/vendor/jquery.js"></script>
	<script src="assets/js/foundation.min.js"></script>
	<script src="assets/js/foundation/foundation.js"></script>
	<script src="assets/js/foundation/foundation.equalizer.js"></script>   
	<script src="assets/js/foundation/foundation.reveal.js"></script>
	<script src="assets/js/foundation/foundation.tooltip.js"></script>
	<script src="assets/js/intercom.js"></script>
	<script src="assets/js/main.js"></script>

	<script src="assets/js/custom.js"></script>
	<script type="text/javascript">
	<!-- custom scripts -->

	</script>
   
  	</section>
  </body>
</html>
