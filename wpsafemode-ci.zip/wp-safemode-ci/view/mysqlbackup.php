<?php


//print_r($this->data['mysql']['tables']);
// Clear destination table