<?php
/**
* 
* WP Safe Mode v0.06 beta 
* @author CloudIndustry - http://cloud-industry.com 
* @author and contributors Nikola Kirincic, Marko Tiosavljevic, Daliborka Ciric, Luka Cvetinovic , Nikola Stojanovic
* @see For more information about installation, usage, licensing and other notes see README 
  @author
*/



define('WPSM',true);

include_once('autoload.php');